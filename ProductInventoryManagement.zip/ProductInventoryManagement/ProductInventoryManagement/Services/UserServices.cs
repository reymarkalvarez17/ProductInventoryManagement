﻿using ProductInventoryManagement.Models;

namespace ProductInventoryManagement.Services
{
    public class UserService
    {
        public UserType? CurrentUser { get; private set; }

        public event Action? OnChange;

        public void SetUser(UserType user)
        {
            user.IsLoggedIn = true; // mark as logged in
            CurrentUser = user;
            OnChange?.Invoke(); // notify subscribers
        }

        public void Logout()
        {
            if (CurrentUser != null)
            {
                CurrentUser.IsLoggedIn = false; // mark as logged out
            }
            CurrentUser = null;
            OnChange?.Invoke();
        }

    }
}
