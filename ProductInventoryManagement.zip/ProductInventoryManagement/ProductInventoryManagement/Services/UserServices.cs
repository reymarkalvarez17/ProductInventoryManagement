﻿using ProductInventoryManagement.Models;

namespace ProductInventoryManagement.Services
{
    public class UserService
    {
        public UserType? CurrentUser { get; private set; }

        public event Action? OnChange;

        public void SetUser(UserType user)
        {
            CurrentUser = user;
            OnChange?.Invoke(); // notify subscribers
        }

        public void Logout()
        {
            CurrentUser = null;
            OnChange?.Invoke();
        }
    }
}
