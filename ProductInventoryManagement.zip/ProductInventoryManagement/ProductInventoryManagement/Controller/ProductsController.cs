﻿using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductInventoryManagement.Data;
using ProductInventoryManagement.Models;



namespace ProductInventoryManagement.Controller
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly ProductDbContext _context;

        public ProductsController(ProductDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var products = await _context.Products
            .FromSqlRaw("CALL sp_get_all_products()")
            .ToListAsync();
            return Ok(products);
        }
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var products = await _context.Products.FindAsync(id);
            if (products == null) return NotFound($"Product with ID {id} does not exist.");

            var product = await _context.Products
                .FromSqlRaw("CALL sp_get_product_by_id({0});", id)
                .AsNoTracking()
                .ToListAsync();
      
            return Ok(product.FirstOrDefault());

            

            
        }
        [HttpPost]
        public async Task<IActionResult> Add([FromBody] Product product) 
        {
            //Saving just for reference

            //var existingProduct = await _context.Products.FindAsync(product.Id);
            //if (existingProduct != null)
            //    return BadRequest($"Product with ID {product.Id} already exist.");

            //await _context.Database.ExecuteSqlRawAsync(
            //"CALL sp_add_products({0}, {1}, {2}, {3})",
            //product.Name, product.Description, product.Price, product.Quantity);

            ////_context.Products.Add(product);
            ////await _context.SaveChangesAsync();
            //return CreatedAtAction(nameof(GetById), new { id = product.Id }, product);

            var newIdResult = await _context.Products
            .FromSqlRaw("CALL sp_add_products({0}, {1}, {2}, {3})",
            product.Name, product.Description, product.Price, product.Quantity)
            .ToListAsync();

            int newId = newIdResult.FirstOrDefault()?.Id ?? 0;
            product.Id = newId;

            return CreatedAtAction(nameof(GetById), new { id = product.Id }, product);

        }
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] Product product)
        {
            var existingProduct = await _context.Products.FindAsync(id);

            if (product == null)
                return BadRequest("Product data is required.");

            

            // Check if the ID exists
            else if (existingProduct == null)
            {
                return NotFound($"Product with ID {id} does not exist.");

            }
            else
            { 
                // Call stored procedure to update
                await _context.Database.ExecuteSqlRawAsync(
                    "CALL sp_update_products({0}, {1}, {2}, {3}, {4})",
                    id, product.Name, product.Description, product.Price, product.Quantity);

            product.Id = id;
            return Ok(product);
            
            }

        }
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var productToDelete = await _context.Products.FindAsync(id);
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                await _context.Database.ExecuteSqlRawAsync(
                "CALL sp_delete_product({0})", id);
                return Ok(productToDelete);
            }
            return NotFound($"Product {id} Not Found");
            
        }
    }
}
