﻿using Microsoft.EntityFrameworkCore;
using ProductInventoryManagement.Data;
using ProductInventoryManagement.Models;

namespace ProductInventoryManagement.Repositories
{
    public class ProductsRepository
    {
        private readonly ProductDbContext _context;

        public ProductsRepository(ProductDbContext context)
        {
            _context = context;
        }
        public async Task<List<Product>> GetProductsAsync()
        {
            var products = await _context.Products
            .FromSqlRaw("CALL sp_get_all_products()")
            .ToListAsync();

            return products;
        }
        public async Task<Product?> GetProductByIdAsync(int id)
        {
            var product = await _context.Products
                .FromSqlRaw("CALL sp_get_product_by_id({0});", id)
                .AsNoTracking()
                .ToListAsync();

            return product.FirstOrDefault();
        }
        public async Task UpdateProductAsync(Product product)
        {
            await _context.Database.ExecuteSqlRawAsync(
            "CALL sp_update_products({0}, {1}, {2}, {3}, {4})",
            product.Id, product.Name, product.Description, product.Price, product.Quantity);
        }
        public async Task AddProductAsync(Product product)
        {
            await _context.Database.ExecuteSqlRawAsync(
            "CALL sp_add_products({0}, {1}, {2}, {3})",
            product.Name, product.Description, product.Price, product.Quantity);
        }
        public async Task DeleteProductAsync(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                await _context.Database.ExecuteSqlRawAsync(
                "CALL sp_delete_product({0})", id);
            }
        }
    }
}
