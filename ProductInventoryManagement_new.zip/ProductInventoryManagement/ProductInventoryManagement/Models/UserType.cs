﻿using System.ComponentModel.DataAnnotations;

namespace ProductInventoryManagement.Models
{
    public class UserType
    {
        public UserType()
        {
            
        }
        [Required(ErrorMessage = "Username is required")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; } = string.Empty;
        public bool IsLoggedIn { get; set; } = false;
    }
}
