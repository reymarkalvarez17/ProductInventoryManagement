using Microsoft.EntityFrameworkCore;
using ProductInventoryManagement.Components;
using ProductInventoryManagement.Data;
using ProductInventoryManagement.Repositories;
using ProductInventoryManagement.Services;

var builder = WebApplication.CreateBuilder(args);



var ProductsVersion = new MySqlServerVersion(new Version(8, 0, 33));

// MySQL connection string
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
// Add services to the container.
builder.Services.AddDbContext<ProductDbContext>(options =>
    options.UseMySql(connectionString, ProductsVersion));

builder.Services.AddControllers();
builder.Services.AddRazorComponents().AddInteractiveServerComponents();

builder.Services.AddScoped<ProductsRepository>();
builder.Services.AddScoped<UserService>();
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

// Register HttpClient pointing to your API base URL
builder.Services.AddHttpClient("MyApi", client =>
{
    client.BaseAddress = new Uri("https://localhost:7081/"); // Your API base URL
});

builder.Services.AddScoped(sp => sp.GetRequiredService<IHttpClientFactory>().CreateClient("MyApi"));



var app = builder.Build();

app.MapControllers();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();

app.Run();
