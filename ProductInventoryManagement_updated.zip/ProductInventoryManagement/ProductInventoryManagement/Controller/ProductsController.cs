﻿using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductInventoryManagement.Components.Pages;
using ProductInventoryManagement.Data;
using ProductInventoryManagement.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;



namespace ProductInventoryManagement.Controller
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly ProductDbContext _context;

        public ProductsController(ProductDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var products = await _context.Products
            .FromSqlRaw("CALL sp_get_all_products()")
            .ToListAsync();
            return Ok(products);
        }
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var products = await _context.Products.FindAsync(id);
            if (products == null) return NotFound($"Product with ID {id} does not exist.");

            var product = await _context.Products
                .FromSqlRaw("CALL sp_get_product_by_id({0});", id)
                .AsNoTracking()
                .ToListAsync();
      
            return Ok(product.FirstOrDefault());

            

            
        }
        [HttpGet("search/{name}")]
        public async Task<IActionResult> GetByName(string name)
        {
            if(string.IsNullOrWhiteSpace(name))
            return BadRequest("Name cannot be empty.");

            var products = await _context.Products
                .FromSqlRaw("CALL sp_search_product_name({0});", name)
                .AsNoTracking()
                .ToListAsync();

            if(products == null || products.Count == 0)
             return NotFound($"No products found containing '{name}'.");
            return Ok(products);




        }
        [HttpPost]
        public async Task<IActionResult> Add([FromBody] Product product) 
        {
        
            var newIdResult = await _context.Products
            .FromSqlRaw("CALL sp_add_products({0}, {1}, {2}, {3})",
            product.Name, product.Description, product.Price, product.Quantity)
            .ToListAsync();

            int newId = newIdResult.FirstOrDefault()?.Id ?? 0;
            product.Id = newId;

            return CreatedAtAction(nameof(GetById), new { id = product.Id }, product);

        }
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] Product product)
        {

            if (product == null)
                return BadRequest("Product data is required.");

            var existingProduct = await _context.Products.FindAsync(id);
            // Check if the ID exists
            if (existingProduct == null)
            {
                return NotFound($"Product with ID {id} does not exist.");
            }
           
            //if Changes == false not true
            if (!HasChanges(existingProduct,product))
                return BadRequest("No changes detected.");

            try
            {
                // Call stored procedure to update
                await _context.Database.ExecuteSqlRawAsync(
                    "CALL sp_update_products({0}, {1}, {2}, {3}, {4})",
                    id, product.Name, product.Description, product.Price, product.Quantity);

                product.Id = id;
                return Ok(product);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Database error: {ex.Message}");
            }
        }
        private bool HasChanges(Product existing, Product updated) =>
            existing.Name != updated.Name ||
            existing.Description != updated.Description ||
            existing.Price != updated.Price ||
            existing.Quantity != updated.Quantity;

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                await _context.Database.ExecuteSqlRawAsync(
                "CALL sp_delete_product({0})", id);
                return Ok(product);
            }
            
            return NotFound($"Product {id} Not Found");
            
        }

        
    }
}
